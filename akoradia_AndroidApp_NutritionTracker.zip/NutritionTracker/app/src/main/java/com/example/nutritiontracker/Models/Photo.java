package com.example.nutritiontracker.Models;

public class Photo {
    public String thumb;
    public Object highres;
    public boolean is_user_uploaded;
}
