/**
 * Author: Ashay Koradia
 * AndrewId: akoradia
 *
 * The RequestManager class is responsible for handling all network communication
 * between the Android app and the nutrition web service. It sends food queries to
 * the server and processes the nutrition data responses.
 *
 * Key features:
 * - Sends food queries with device information to the web service
 * - Parses JSON responses into usable nutrition data objects
 * - Creates visual pie charts to display macronutrient breakdowns
 * - Calculates total nutrition values for display
 *
 * This class uses HttpURLConnection for network operations and runs them in
 * background threads to keep the UI responsive. It also captures device information
 * to help with analytics on the server side.
 */

package com.example.nutritiontracker;

// Android UI and system imports
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

// Model classes for request/response handling
import com.example.nutritiontracker.Models.NaturalNutrientsRequest;
import com.example.nutritiontracker.Models.NaturalNutrientsResponse;
import com.example.nutritiontracker.Models.Food;

// MPAndroidChart library for pie chart visualization
// Note: You may see IDE errors for these imports, but the library works correctly at runtime
// This is a common issue with libraries from JitPack and doesn't affect app functionality
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

// JSON parsing and networking imports
import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONObject;

// Java IO and networking imports
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * The RequestManager class handles all API communication for the Nutrition Tracker app.
 * It sends food queries to the nutrition web service and processes the responses,
 * including creating visual representations of the nutrition data.
 */
public class RequestManager {
    // Store the application context for UI updates
    private Context context;

    /**
     * Constructor for the RequestManager.
     * 
     * @param context The application context, used to update UI elements
     *               after receiving network responses
     */
    public RequestManager(Context context) {
        this.context = context;
    }

    /**
     * Fetches nutrition information for a food query from the web service.
     * 
     * This method performs the following operations:
     * 1. Creates a network connection to the nutrition web service
     * 2. Collects device information (manufacturer, model, OS version)
     * 3. Sends the food query along with device info to the server
     * 4. Processes the JSON response into nutrition data objects
     * 5. Updates the UI with both visual (pie chart) and text representations
     * 
     * The method runs in a background thread to avoid blocking the UI thread
     * during network operations.
     * 
     * @param query The food description entered by the user (e.g., "1 apple")
     */
    public void fetchNutrients(String query) {
        // Run network operations in a background thread to keep UI responsive
        new Thread(() -> {
            try {
                // Create connection to the nutrition web service
                // Using URI instead of direct URL constructor (which is deprecated)
                java.net.URI uri = new java.net.URI("https://super-waffle-g5rpgvqqrgjh66q-8080.app.github.dev/Project-4-mongo-nutrition-web-app/api/nutrition");
                URL url = uri.toURL();
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                // Collect device information for analytics and tracking
                // This helps the web service understand what devices are using the app
                String manufacturer = android.os.Build.MANUFACTURER;  // Device manufacturer
                String model = android.os.Build.MODEL;               // Device model
                String deviceInfo = manufacturer + " " + model;      // Combined device info
                String osVersion = "Android " + android.os.Build.VERSION.RELEASE;  // OS version
                
                // Create a structured request object with both the food query and device info
                // Using a model class ensures consistent formatting of the request
                NaturalNutrientsRequest request = new NaturalNutrientsRequest(
                    query,          // The food the user wants nutrition info for
                    model,          // Device model
                    manufacturer,   // Device manufacturer
                    deviceInfo,     // Combined device info
                    osVersion       // OS version
                );
                
                // Convert the request object to a JSON string using Gson library
                // This is more reliable than manually building JSON
                com.google.gson.Gson gson = new com.google.gson.Gson();
                String jsonString = gson.toJson(request);
                
                // Log information for debugging purposes
                Log.d("DeviceInfo", "Sending device info: " + deviceInfo);
                Log.d("ApiRequest", "Sending request: " + jsonString);
                
                // Send the JSON data to the server
                OutputStream os = conn.getOutputStream();
                os.write(jsonString.getBytes("UTF-8"));  // Convert string to bytes with UTF-8 encoding
                os.close();  // Always close streams when done

                // Read the response data from the server
                // We use BufferedReader for efficient reading of text data
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder response = new StringBuilder();
                String line;
                
                // Read the response line by line and build a complete string
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                
                // Convert the response to a string for processing
                String responseStr = response.toString();
                Log.d("NutritionResponse", "Raw response: " + responseStr);
                
                // Create objects to hold the nutrition data
                // We'll manually populate these from the JSON response
                NaturalNutrientsResponse nutrientsResponse = new NaturalNutrientsResponse();
                List<Food> foodsList = new ArrayList<>();  // List to hold individual food items
                
                try {
                    // Parse the JSON string into a JSONObject for easier data extraction
                    JSONObject jsonResponse = new JSONObject(responseStr);
                    
                    // Check if the response contains a "foods" array
                    // This is where all the nutrition information is stored
                    if (jsonResponse.has("foods")) {
                        JSONArray foodsArray = jsonResponse.getJSONArray("foods");
                        
                        // Process each food item in the array
                        for (int i = 0; i < foodsArray.length(); i++) {
                            JSONObject foodObj = foodsArray.getJSONObject(i);
                            
                            // Create a new Food object to store the nutrition data
                            Food food = new Food();
                            
                            // Extract nutrition values from the JSON
                            // The optString/optDouble methods safely handle missing fields with default values
                            String foodName = foodObj.optString("foodName");      // Name of the food item
                            double calories = foodObj.optDouble("calories");       // Calories in kcal
                            double totalFat = foodObj.optDouble("totalFat");      // Fat content in grams
                            double totalCarbs = foodObj.optDouble("totalCarbohydrate"); // Carbs in grams
                            double protein = foodObj.optDouble("protein");        // Protein in grams
                            
                            // Log the extracted values for debugging and verification
                            Log.d("FoodExtract", "Food #" + i + ": " + 
                                  "name=" + foodName + ", " +
                                  "calories=" + calories + ", " +
                                  "fat=" + totalFat + ", " +
                                  "carbs=" + totalCarbs + ", " +
                                  "protein=" + protein);
                            
                            // Set the values using Java Reflection API
                            // We use reflection to set private fields directly instead of using setter methods
                            // This gives us more flexibility when working with different API response formats
                            try {
                                // Set the food name field
                                Field foodNameField = Food.class.getDeclaredField("foodName");
                                foodNameField.setAccessible(true);  // Allow access to private field
                                foodNameField.set(food, foodName);  // Set the string value
                                
                                // Set the calories field
                                Field caloriesField = Food.class.getDeclaredField("calories");
                                caloriesField.setAccessible(true);  // Allow access to private field
                                caloriesField.setDouble(food, calories);  // Set the numeric value
                                
                                // Set the total fat field
                                Field fatField = Food.class.getDeclaredField("totalFat");
                                fatField.setAccessible(true);  // Allow access to private field
                                fatField.setDouble(food, totalFat);  // Set the numeric value
                                
                                // Set the total carbohydrates field
                                Field carbsField = Food.class.getDeclaredField("totalCarbohydrate");
                                carbsField.setAccessible(true);  // Allow access to private field
                                carbsField.setDouble(food, totalCarbs);  // Set the numeric value
                                
                                // Set the protein field
                                Field proteinField = Food.class.getDeclaredField("protein");
                                proteinField.setAccessible(true);  // Allow access to private field
                                proteinField.setDouble(food, protein);  // Set the numeric value
                                
                                // Add the populated food object to our list
                                foodsList.add(food);
                                // Log successful addition for debugging
                                Log.d("FoodDebug", "Added food: " + food.getFoodName() + ", calories: " + food.getCalories());
                            } catch (Exception e) {
                                // Log any errors that occur during reflection
                                // This helps identify issues with field names or data types
                                Log.e("NutritionError", "Error setting food fields: " + e.getMessage(), e);
                            }
                        }
                    }
                    
                    // Set the complete list of foods in the response object
                    // This will be used to display the nutrition information to the user
                    nutrientsResponse.setFoods(foodsList);
                    
                } catch (Exception e) {
                    // Handle any JSON parsing errors that might occur
                    // This could happen if the server returns malformed JSON
                    Log.e("NutritionError", "JSON parsing error: " + e.getMessage(), e);
                }

                // Log the parsed response for debugging
                Log.d("NutritionParsed", "Parsed response: " + (nutrientsResponse != null ? nutrientsResponse.toString() : "null"));
                
                // Verify that we have food data to display
                if (nutrientsResponse != null && nutrientsResponse.getFoods() != null) {
                    Log.d("NutritionParsed", "Foods count: " + nutrientsResponse.getFoods().size());
                } else {
                    Log.d("NutritionParsed", "Foods is null or empty");
                }

                // Format the nutrition data as a readable string using the toString() method
                // This provides a detailed text representation of all nutrition information
                final String formatted = nutrientsResponse != null ? nutrientsResponse.toString() : "No nutrition data available";
                
                // Calculate total nutrition values for the pie chart visualization
                // These calculations sum up the values across all food items in the response
                final double totalFat = calculateTotalNutrient(nutrientsResponse, "totalFat");           // Total fat in grams
                final double totalCarbs = calculateTotalNutrient(nutrientsResponse, "totalCarbohydrate"); // Total carbs in grams
                final double totalProtein = calculateTotalNutrient(nutrientsResponse, "protein");        // Total protein in grams
                final double totalCalories = calculateTotalNutrient(nutrientsResponse, "calories");      // Total calories
                
                // Update the UI on the main thread
                // Network operations run on a background thread, but UI updates must happen on the main thread
                ((Activity) context).runOnUiThread(() -> {
                    // Update the text view with detailed nutrition information
                    TextView textViewResult = ((Activity) context).findViewById(R.id.textViewResult);
                    textViewResult.setText(formatted);
                    
                    // Update and show the total calories text view
                    // This provides a clear, prominent display of the most important nutrition metric
                    TextView textViewTotalCalories = ((Activity) context).findViewById(R.id.textViewTotalCalories);
                    textViewTotalCalories.setText("Total Calories: " + String.format("%.1f", totalCalories));
                    textViewTotalCalories.setVisibility(View.VISIBLE);
                    
                    // Create and display the pie chart visualization
                    // This gives users a visual breakdown of macronutrients (fat, carbs, protein)
                    PieChart pieChart = ((Activity) context).findViewById(R.id.nutritionPieChart);
                    setupPieChart(pieChart, totalFat, totalCarbs, totalProtein);
                    pieChart.setVisibility(View.VISIBLE);
                });

            } catch (Exception e) {
                // Print stack trace for detailed debugging
                e.printStackTrace();
                // Log the error for easier debugging in Android Studio
                Log.e("NutritionError", "Exception while fetching nutrients", e);
                
                // Update UI on the main thread to show the error message
                ((Activity) context).runOnUiThread(() -> {
                    // Display a user-friendly error message
                    TextView textViewResult = ((Activity) context).findViewById(R.id.textViewResult);
                    textViewResult.setText("Failed to retrieve nutrition data. Please try again.\nError: " + e.getMessage());
                    
                    // Hide the visualization elements when there's an error
                    // This prevents showing empty or incorrect charts to the user
                    ((Activity) context).findViewById(R.id.nutritionPieChart).setVisibility(View.GONE);
                    ((Activity) context).findViewById(R.id.textViewTotalCalories).setVisibility(View.GONE);
                });
            }
        }).start();
    }
    
    /**
     * Calculate the total amount of a specific nutrient from all foods in the response
     * 
     * This method sums up a particular nutrient (calories, fat, carbs, or protein)
     * across all food items returned by the API. This is useful for displaying
     * total nutrition information and creating the pie chart visualization.
     * 
     * @param response The nutrition response object containing food items
     * @param nutrientName The name of the nutrient to calculate ("calories", "totalFat", etc.)
     * @return The total amount of the specified nutrient across all foods (in grams, or calories)
     */
    private double calculateTotalNutrient(NaturalNutrientsResponse response, String nutrientName) {
        // Check if we have valid data to work with
        // Return 0 if there's no response, no foods, or an empty foods list
        if (response == null || response.getFoods() == null || response.getFoods().isEmpty()) {
            return 0;
        }
        
        // Initialize the total counter
        double total = 0;
        
        // Loop through each food item and add up the specified nutrient
        for (Food food : response.getFoods()) {
            try {
                // Add the appropriate nutrient value based on the nutrient name
                if (nutrientName.equals("calories")) {
                    total += food.getCalories();  // Add calories (in kcal)
                } else if (nutrientName.equals("totalFat")) {
                    total += food.getTotalFat();  // Add fat (in grams)
                } else if (nutrientName.equals("totalCarbohydrate")) {
                    total += food.getTotalCarbohydrate();  // Add carbs (in grams)
                } else if (nutrientName.equals("protein")) {
                    total += food.getProtein();  // Add protein (in grams)
                }
            } catch (Exception e) {
                // Log any errors but continue processing other foods
                Log.e("NutritionError", "Error calculating total for " + nutrientName, e);
            }
        }
        
        // Return the calculated total
        return total;
    }
    
    /**
     * Set up the pie chart with nutrition data
     * 
     * This method configures a pie chart to display the macronutrient breakdown
     * of the food items. It creates a visually appealing chart with custom colors
     * for each macronutrient (fat, carbs, protein) and handles edge cases like
     * missing data.
     * 
     * @param pieChart The PieChart view to configure
     * @param fat The total fat content in grams
     * @param carbs The total carbohydrate content in grams
     * @param protein The total protein content in grams
     */
    private void setupPieChart(PieChart pieChart, double fat, double carbs, double protein) {
        // Create a list to hold the pie chart data entries
        ArrayList<PieEntry> entries = new ArrayList<>();
        
        // Only add entries for nutrients with non-zero values
        // This prevents the chart from showing empty or meaningless segments
        if (fat > 0) entries.add(new PieEntry((float)fat, "Fat"));
        if (carbs > 0) entries.add(new PieEntry((float)carbs, "Carbs"));
        if (protein > 0) entries.add(new PieEntry((float)protein, "Protein"));
        
        // Handle the case where all nutrients are zero
        // This ensures the chart always shows something, even with no data
        if (entries.isEmpty()) {
            entries.add(new PieEntry(1, "No Data"));
        }
        
        // Create a dataset from the entries and configure its appearance
        PieDataSet dataSet = new PieDataSet(entries, "Nutrition Breakdown (g)");
        
        // Define custom colors for each nutrient type
        // Using distinct colors helps users quickly identify each macronutrient
        int[] colors = new int[]{
            Color.rgb(255, 102, 0),  // Orange for Fat
            Color.rgb(51, 153, 255), // Blue for Carbs
            Color.rgb(0, 204, 102)   // Green for Protein
        };
        
        // Apply the colors and configure text appearance
        dataSet.setColors(colors);
        dataSet.setValueTextSize(14f);              // Set text size for readability
        dataSet.setValueTextColor(Color.WHITE);     // White text for better contrast
        dataSet.setValueFormatter(new PercentFormatter(pieChart));  // Show values as percentages
        
        // Create pie data and set it to the chart
        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        
        // Configure pie chart appearance
        pieChart.getDescription().setEnabled(false);
        pieChart.setUsePercentValues(true);
        pieChart.setEntryLabelTextSize(14f);
        pieChart.setEntryLabelColor(Color.WHITE);
        pieChart.setCenterText("Macros");
        pieChart.setCenterTextSize(18f);
        pieChart.setHoleRadius(40f);
        pieChart.setTransparentCircleRadius(45f);
        pieChart.setDrawEntryLabels(true);
        pieChart.setDrawCenterText(true);
        pieChart.setRotationEnabled(true);
        pieChart.setHighlightPerTapEnabled(true);
        pieChart.animateY(1000);
        pieChart.invalidate(); // Refresh the chart
    }
}