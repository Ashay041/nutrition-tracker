package com.example.nutritiontracker.Models;

public class Common {
    public int serving_qty;
    public int common_type;
    public String serving_unit;
    public String tag_id;
    public Photo photo;
    public String food_name;
    public String tag_name;
    public String locale;
}
