/**
 * Author: Ashay Koradia
 * AndrewId: akoradia
 *
 * MainActivity is the entry point for the Nutrition Tracker application.
 * This activity provides a simple user interface for entering food items
 * and displaying their nutritional information.
 *
 * The app allows users to:
 * - Enter food items they've consumed
 * - View detailed nutrition information for those foods
 * - See a visual breakdown of macronutrients via a pie chart
 *
 * The UI consists of a text input field, a button to submit queries,
 * and areas to display the nutrition data both as text and in chart form.
 */
package com.example.nutritiontracker;

// Android UI and system imports
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity serves as the main screen of the Nutrition Tracker app.
 * It handles user input and displays nutrition information results.
 */
public class MainActivity extends AppCompatActivity {
    // UI elements for user interaction
    private EditText editTextQuery;   // Input field for food query
    private Button buttonFetch;       // Button to submit the query
    private TextView textViewResult; // Text area to display nutrition results
    
    // Manager class that handles API requests and response processing
    private RequestManager requestManager;

    /**
     * Initializes the activity when it's created
     * 
     * This method sets up the user interface, connects to UI elements,
     * and configures event listeners for user interactions.
     * 
     * @param savedInstanceState Contains data supplied if the activity 
     *                           is being re-initialized after previously being shut down
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout for this activity from the XML resource
        setContentView(R.layout.activity_main);

        // Connect variables to their corresponding UI elements in the layout
        editTextQuery = findViewById(R.id.editTextQuery);   // The text input field
        buttonFetch = findViewById(R.id.buttonFetch);       // The submit button
        textViewResult = findViewById(R.id.textViewResult); // The results display area

        // Create the request manager that will handle API communication
        requestManager = new RequestManager(this);

        // Set up the button click listener to handle user input
        buttonFetch.setOnClickListener(new View.OnClickListener() {
            /**
             * Handles button click events
             * 
             * When the user clicks the fetch button, this method extracts the food query
             * from the input field and sends it to the RequestManager for processing.
             * If the input is empty, it shows a helpful error message.
             * 
             * @param view The button that was clicked
             */
            @Override
            public void onClick(View view) {
                // Get the text from the input field
                String query = editTextQuery.getText().toString();
                
                // Only proceed if the user entered something
                if (!query.isEmpty()) {
                    // Send the query to the RequestManager to fetch nutrition data
                    requestManager.fetchNutrients(query);
                } else {
                    // Show a friendly error message if the input is empty
                    Toast.makeText(MainActivity.this, "Please enter what you ate", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}