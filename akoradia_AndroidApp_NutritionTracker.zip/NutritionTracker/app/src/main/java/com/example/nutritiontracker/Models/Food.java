/**
 * Author: Ashay Koradia
 * AndrewId: akoradia
 *
 * The Food class represents a single food item with its nutritional information.
 * This class handles both the custom server response format and direct Nutritionix API
 * response format by providing alternative field mappings.
 *
 * Each Food object contains information about calories, fats, carbohydrates, and proteins
 * for a specific food item. The getter methods automatically select the appropriate value
 * based on which field is populated.
 */
package com.example.nutritiontracker.Models;

// Gson annotation for JSON field naming
import com.google.gson.annotations.SerializedName;

/**
 * Model class for food items and their nutritional information
 * 
 * This class is designed to handle multiple API response formats by providing
 * alternative field mappings for each nutritional property. The getter methods
 * intelligently select the appropriate value.
 */
public class Food {

    /**
     * Primary field for the food item name
     * Used with our custom server response format
     */
    @SerializedName("foodName")
    private String foodName;

    /**
     * Primary field for calories
     * Value in kilocalories
     */
    @SerializedName("calories")
    private double calories;

    /**
     * Primary field for total fat content
     * Value in grams
     */
    @SerializedName("totalFat")
    private double totalFat;

    /**
     * Primary field for total carbohydrate content
     * Value in grams
     */
    @SerializedName("totalCarbohydrate")
    private double totalCarbohydrate;

    /**
     * Primary field for protein content
     * Value in grams
     */
    @SerializedName("protein")
    private double protein;

    /**
     * Alternative field for food name
     * Used with direct Nutritionix API responses
     */
    @SerializedName("food_name")
    private String foodNameAlt;

    /**
     * Alternative field for calories
     * Used with direct Nutritionix API responses
     * Value in kilocalories
     */
    @SerializedName("nf_calories")
    private double caloriesAlt;

    /**
     * Alternative field for total fat
     * Used with direct Nutritionix API responses
     * Value in grams
     */
    @SerializedName("nf_total_fat")
    private double totalFatAlt;

    /**
     * Alternative field for total carbohydrates
     * Used with direct Nutritionix API responses
     * Value in grams
     */
    @SerializedName("nf_total_carbohydrate")
    private double totalCarbohydrateAlt;

    /**
     * Alternative field for protein
     * Used with direct Nutritionix API responses
     * Value in grams
     */
    @SerializedName("nf_protein")
    private double proteinAlt;

    /**
     * Gets the name of the food item
     * 
     * This method intelligently selects between the primary and alternative
     * field values based on which one is populated. If the primary field is
     * null, it falls back to the alternative field.
     * 
     * @return The name of the food item
     */
    public String getFoodName() {
        return foodName != null ? foodName : foodNameAlt;
    }

    /**
     * Gets the calorie content of the food item
     * 
     * This method intelligently selects between the primary and alternative
     * field values based on which one is populated. If the primary field is
     * zero or negative, it falls back to the alternative field.
     * 
     * @return The calorie content in kilocalories
     */
    public double getCalories() {
        return calories > 0 ? calories : caloriesAlt;
    }

    /**
     * Gets the total fat content of the food item
     * 
     * This method intelligently selects between the primary and alternative
     * field values based on which one is populated. If the primary field is
     * zero or negative, it falls back to the alternative field.
     * 
     * @return The total fat content in grams
     */
    public double getTotalFat() {
        return totalFat > 0 ? totalFat : totalFatAlt;
    }

    /**
     * Gets the total carbohydrate content of the food item
     * 
     * This method intelligently selects between the primary and alternative
     * field values based on which one is populated. If the primary field is
     * zero or negative, it falls back to the alternative field.
     * 
     * @return The total carbohydrate content in grams
     */
    public double getTotalCarbohydrate() {
        return totalCarbohydrate > 0 ? totalCarbohydrate : totalCarbohydrateAlt;
    }

    /**
     * Gets the protein content of the food item
     * 
     * This method intelligently selects between the primary and alternative
     * field values based on which one is populated. If the primary field is
     * zero or negative, it falls back to the alternative field.
     * 
     * @return The protein content in grams
     */
    public double getProtein() {
        return protein > 0 ? protein : proteinAlt;
    }
}