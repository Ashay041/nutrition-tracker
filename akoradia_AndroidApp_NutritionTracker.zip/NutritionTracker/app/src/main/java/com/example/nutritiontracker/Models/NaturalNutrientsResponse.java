/**
 * Author: Ashay Koradia
 * AndrewId: akoradia
 *
 * The NaturalNutrientsResponse class represents the response data
 * received from the nutrition web service. It contains a list of
 * food items with their nutritional information.
 *
 * This class is designed to be populated from JSON using Gson or
 * manually constructed from parsed JSON data. It provides methods
 * to access the food data and a formatted string representation
 * of the nutrition information.
 */
package com.example.nutritiontracker.Models;

// Gson annotation for JSON field naming
import com.google.gson.annotations.SerializedName;
// Java collection for storing multiple food items
import java.util.List;

/**
 * Model class for nutrition API responses
 * 
 * This class encapsulates the nutrition data returned from the web service,
 * including a list of food items with their nutritional content.
 */
public class NaturalNutrientsResponse {
    /**
     * List of food items with their nutritional information
     * This is the main data container for the nutrition response
     */
    @SerializedName("foods")
    private List<Food> foods;
    
    /**
     * Default constructor
     * 
     * This constructor is needed for both Gson deserialization
     * and manual construction of the response object.
     */
    public NaturalNutrientsResponse() {
        // Default constructor needed for manual construction and Gson
    }

    /**
     * Gets the list of food items with nutrition data
     * 
     * @return A list of Food objects containing nutrition information
     */
    public List<Food> getFoods() {
        return foods;
    }
    
    /**
     * Sets the list of food items with nutrition data
     * 
     * @param foods A list of Food objects to set
     */
    public void setFoods(List<Food> foods) {
        this.foods = foods;
    }

    /**
     * Converts the nutrition data to a human-readable string format
     * 
     * This method creates a formatted text representation of all nutrition data,
     * including individual food items and totals for calories, fat, carbs, and protein.
     * It's used to display the nutrition information in the app's UI.
     * 
     * @return A formatted string with detailed nutrition information
     */
    @Override
    public String toString() {
        // Handle the case where no food data is available
        if (foods == null || foods.isEmpty()) {
            return "No food data available.";
        }
        
        // Use StringBuilder for efficient string concatenation
        StringBuilder sb = new StringBuilder();
        
        // Initialize counters for total nutrition values
        double totalCalories = 0;
        double totalFat = 0;
        double totalCarbs = 0;
        double totalProtein = 0;

        // Process each food item and add its details to the output
        for (Food food : foods) {
            // Format individual food item details
            sb.append("Food: ").append(food.getFoodName()).append("\n")
                    .append("  Calories: ").append(food.getCalories()).append("\n")
                    .append("  Total Fat: ").append(food.getTotalFat()).append("\n")
                    .append("  Carbohydrates: ").append(food.getTotalCarbohydrate()).append("\n")
                    .append("  Protein: ").append(food.getProtein()).append("\n")
                    .append("--------------------------\n");

            // Add this food's nutrition values to the running totals
            totalCalories += food.getCalories();
            totalFat += food.getTotalFat();
            totalCarbs += food.getTotalCarbohydrate();
            totalProtein += food.getProtein();
        }

        // Add the total nutrition summary at the end
        sb.append("TOTAL INTAKE:\n")
                .append("  Calories: ").append(totalCalories).append("\n")
                .append("  Total Fat: ").append(totalFat).append("\n")
                .append("  Carbohydrates: ").append(totalCarbs).append("\n")
                .append("  Protein: ").append(totalProtein);

        return sb.toString();
    }
}