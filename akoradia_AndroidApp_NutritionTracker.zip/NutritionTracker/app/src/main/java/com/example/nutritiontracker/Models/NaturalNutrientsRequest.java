/**
 * Author: Ashay Koradia
 * AndrewId: akoradia
 *
 * The NaturalNutrientsRequest class represents the request structure
 * sent to the nutrition web service. It contains both the food query
 * and device information for analytics purposes.
 *
 * This class is designed to be serialized to JSON using Gson before
 * being sent to the server. The @SerializedName annotations ensure
 * that the field names match what the server expects.
 */
package com.example.nutritiontracker.Models;

// Gson annotation for JSON field naming
import com.google.gson.annotations.SerializedName;

/**
 * Model class for nutrition API requests
 * 
 * This class encapsulates all the information needed to make a request
 * to the nutrition web service, including both the food query and
 * device-specific information for analytics.
 */
public class NaturalNutrientsRequest {
    /**
     * The food item query entered by the user
     */
    @SerializedName("query")
    private String query;
    
    /**
     * The device model information
     */
    @SerializedName("deviceModel")
    private String deviceModel;
    
    /**
     * The device manufacturer information
     */
    @SerializedName("deviceManufacturer")
    private String deviceManufacturer;
    
    /**
     * Combined device information string
     */
    @SerializedName("deviceInfo")
    private String deviceInfo;
    
    /**
     * Operating system version information
     */
    @SerializedName("osVersion")
    private String osVersion;

    /**
     * Simple constructor with just the food query
     * 
     * @param query The food item(s) to get nutrition information for
     */
    public NaturalNutrientsRequest(String query) {
        this.query = query;
    }
    
    /**
     * Full constructor with device information for analytics
     * 
     * @param query The food item(s) to get nutrition information for
     * @param deviceModel The model of the user's device
     * @param deviceManufacturer The manufacturer of the user's device
     * @param deviceInfo Combined device information string
     * @param osVersion The operating system version
     */
    public NaturalNutrientsRequest(String query, String deviceModel, String deviceManufacturer, String deviceInfo, String osVersion) {
        this.query = query;
        this.deviceModel = deviceModel;
        this.deviceManufacturer = deviceManufacturer;
        this.deviceInfo = deviceInfo;
        this.osVersion = osVersion;
    }

    /**
     * Gets the food query string
     * 
     * @return The food query entered by the user
     */
    public String getQuery() {
        return query;
    }

    /**
     * Sets the food query string
     * 
     * @param query The food query to set
     */
    public void setQuery(String query) {
        this.query = query;
    }
    
    /**
     * Gets the device model information
     * 
     * @return The device model
     */
    public String getDeviceModel() {
        return deviceModel;
    }

    /**
     * Sets the device model information
     * 
     * @param deviceModel The device model to set
     */
    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    /**
     * Gets the device manufacturer information
     * 
     * @return The device manufacturer
     */
    public String getDeviceManufacturer() {
        return deviceManufacturer;
    }

    /**
     * Sets the device manufacturer information
     * 
     * @param deviceManufacturer The device manufacturer to set
     */
    public void setDeviceManufacturer(String deviceManufacturer) {
        this.deviceManufacturer = deviceManufacturer;
    }

    /**
     * Gets the combined device information string
     * 
     * @return The combined device info
     */
    public String getDeviceInfo() {
        return deviceInfo;
    }

    /**
     * Sets the combined device information string
     * 
     * @param deviceInfo The device info to set
     */
    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    /**
     * Gets the operating system version
     * 
     * @return The OS version
     */
    public String getOsVersion() {
        return osVersion;
    }

    /**
     * Sets the operating system version
     * 
     * @param osVersion The OS version to set
     */
    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }
}