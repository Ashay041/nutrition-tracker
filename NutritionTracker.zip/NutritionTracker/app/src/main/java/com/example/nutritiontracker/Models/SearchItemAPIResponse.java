package com.example.nutritiontracker.Models;

import java.util.ArrayList;

public class SearchItemAPIResponse {
    public ArrayList<Common> common;
    public ArrayList<Branded> branded;

}
