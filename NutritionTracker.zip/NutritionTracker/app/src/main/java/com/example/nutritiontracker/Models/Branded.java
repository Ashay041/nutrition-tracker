package com.example.nutritiontracker.Models;

public class Branded {
    public String serving_unit;
    public String food_name;
    public int serving_qty;
    public int region;
    public String brand_name_item_name;
    public int brand_type;
    public Photo photo;
    public int nf_calories;
    public String nix_item_id;
    public String brand_name;
    public String nix_brand_id;
    public String locale;
}
